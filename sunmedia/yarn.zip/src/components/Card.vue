<template>
  <div
    @click="onCardClick"
    class="modal-open w-full lg:w-1/2 px-10 md:px-4 lg:px-6 py-5 shadow-md"
  >
    <div class="bg-white hover:shadow-x1">
      <img
        src="../assets/placeholder.png"
        alt="logo"
        @error="handleImageError"
        class="h-56 w-full border-white border-8"
      />
      <div class="px-4 py-4 md:px-10">
        <h1 class="text 2x1 font-black text-gray-900 pb-6 px-6 md:px-12">
          {{ item.school }}
        </h1>
        <div class="w-full h-64 relative">
          <div class="absolute inset-x-0 bottom-0 center">
            <button
              :class="buttonClass"
              class="bg-blue-500 text-white font-bold py-2 px-4 rounded"
              @click="onButtonClick"
            >
              <i class="far fa-star"></i> {{ buttonText }}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapMutations } from "vuex";
import {
  ADD_FAVORITE,
  ADD_MODAL_ITEM,
  REMOVE_FAVORITE,
} from "../store/mutations.js";

export default {
  name: "Card",
  props: {
    item: { type: Object },
  },
  data: () => ({
    active: false,
    addedFavorite: false,
    avatar: null,
  }),
  computed: {
    buttonText() {
      return this.addedFavorite ? "Remove favorite" : "Add favorite";
    },
    buttonClass() {
      return this.addedFavorite
        ? "bg-yellow-300 hover:bg-red-400"
        : "bg-blue-500 hover:bg-yellow-400";
    },
  },
  methods: {
    handleImageError(event) {
      event.target.src = "../assets/placeholder.png";
    },
    sanitizeData(key, value) {
      const blackList = ["logos"];

      return blackList.indexOf(key) === -1 && value !== null;
    },
    ...mapMutations([ADD_FAVORITE, REMOVE_FAVORITE, ADD_MODAL_ITEM]),
    onButtonClick() {
      !this.addedFavorite
        ? this[ADD_FAVORITE](this.item)
        : this[REMOVE_FAVORITE](this.item);

      this.addedFavorite = !this.addedFavorite;
    },
    onCardClick() {
      console.log(this.item);
      this[ADD_MODAL_ITEM](this.item);
    },
  },
  mounted() {
    this.avatar = this.item?.logos?.[0] || null;
  },
};
</script>

<style scoped>
dl {
  width: 100%;
}

dt {
  float: left;
  width: 50%;
  text-align: left;
}

dd {
  float: left;
  width: 50%;
  text-align: right;
}
</style>
