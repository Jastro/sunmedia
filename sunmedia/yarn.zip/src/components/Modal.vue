<template>
  <div
    class="modal opacity-0 pointer-events-none fixed w-full h-full top-0 left-0 flex items-center justify-center"
  >
    <div class="modal-overlay absolute w-full h-full bg-gray-900 opacity-50">
      <div
        class="modal-container bg-white w-11/12 md:max-w mx-auto rounded shadow-lg z-50 overflow-y-auto"
      >
        <div
          class="modal-close absolute top-0 right-0 cursor-pointer flex flex-col items-center mt-4 mr-4 text-white text-sm z-50"
        >
          <span class="text-sm">ESC</span>
        </div>

        <div class="modal-content py-4 text-left px-6">
          <div class="flex justify-between items-center pb-3">
            <p class="text-2x1 font-bold">Modal!</p>
            <div class="modal-close cursor-ponter z-50">
              X
            </div>
          </div>
        </div>

        <!--BODY -->
        <div class="py-4">
          <dl v-for="(value, key, index) in item" :key="index">
            <div v-if="sanitizeData(key, value)">
              <dt>{{ key }}</dt>
              <dd>{{ value }}</dd>
            </div>
          </dl>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    item: { type: Object },
  },
  watch: {
    item(newValue, oldValue) {
      console.log(newValue);
      console.log(oldValue);
      console.log("ITEM CALLED");
    },
  },
  methods: {
    sanitizeData(key, value) {
      const blackList = ["logos"];

      return blackList.indexOf(key) === -1 && value !== null;
    },
  },
};
</script>
