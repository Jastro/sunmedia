export const ADD_ITEMS = "ADD_ITEMS";
export const ADD_FAVORITE = "ADD_FAVORITE";
export const REMOVE_FAVORITE = "REMOVE_FAVORITE";
export const SET_SHOWING_FAVORITE = "SET_SHOWING_FAVORITE";
export const SET_FILTERED_ITEMS = "SET_FILTERED_ITEMS";
export const SET_ITEM_LIMIT = "SET_ITEM_LIMIT";
export const ADD_MODAL_ITEM = "ADD_MODAL_ITEM";

export default {
  [ADD_ITEMS]: (state, items) => {
    state.items = items;
  },
  [ADD_MODAL_ITEM]: (state, item) => {
    state.modalItem = item;
  },
  [ADD_FAVORITE]: (state, favorite) => {
    state.favorites.push(favorite);
  },
  [REMOVE_FAVORITE]: (state, removedItem) => {
    state.favorites = state.favorites.filter(
      (favorite) => favorite.id !== removedItem.id
    );
  },
  [SET_SHOWING_FAVORITE]: (state, value) => {
    state.showingFavorites = value;
  },
  [SET_FILTERED_ITEMS]: (state, items) => {
    state.itemsFiltered = items;
  },
  [SET_ITEM_LIMIT]: (state, limit) => {
    state.showLimit = limit;
  },
};
