<template>
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
    rel="stylesheet"
  />

  <div class="app">
    <Navbar />
    <section class="py-12">
      <div class="container mx-auto">
        <div>
          <h1 class="text-2x1 font-black text-gray-900 pb-6 px-6 md:px-12">
            School List
          </h1>
        </div>
        <div class="flex flex-wrap px-5" v-if="!showingFavorites">
          <Card v-for="item in itemsFiltered" :item="item" :key="item.id" />
        </div>
        <div class="flex flex-wrap px-5" v-else>
          <Card v-for="item in favoritesList" :item="item" :key="item.id" />
        </div>
        <Modal v-if="modalItem" :item="modalItem" />
      </div>
    </section>
  </div>
</template>

<script>
import Navbar from "./components/Navbar.vue";
import Card from "./components/Card.vue";
import Modal from "./components/Modal.vue";
import "tailwindcss/dist/tailwind.css";

import { getColleges } from "./api/colleges.api";
import { mapState, mapMutations } from "vuex";
import { ADD_ITEMS, SET_FILTERED_ITEMS } from "./store/mutations";

export default {
  name: "App",
  components: {
    Card,
    Navbar,
    Modal,
  },
  data: () => ({
    itemsList: null,
    favoritesList: [],
    logo: null,
    modalItem: null,
  }),
  computed: mapState([
    "showingFavorites",
    "items",
    "favorites",
    "itemsFiltered",
    "showLimit",
    "modalItem",
  ]),
  watch: {
    modalItem(newValue, oldValue) {
      console.log(newValue);
      console.log(oldValue);
      console.log("TOGGLE MODAL");
    },
  },
  methods: {
    ...mapMutations([ADD_ITEMS, SET_FILTERED_ITEMS]),
    setItems() {
      this[ADD_ITEMS](this.itemsList);
      this.limitedItems = this.items.slice(0, this.showLimit);
      this[SET_FILTERED_ITEMS](this.limitedItems);
      this.favoritesList = this.favorites;
    },
    toggleModal() {
      const modal = document.querySelector(".modal");
      modal.classList.toggle("opacity-0");
      modal.classList.toggle("pointer-events-none");
    },
    loadModals() {
      const modals = document.querySelectorAll(".modal-open");
      console.log("modals", JSON.stringify(modals));
      modals.forEach((modal) =>
        modal.addEventListener("click", (e) => {
          e.preventDefault();
          this.toggleModal();
        })
      );

      const overlay = document.querySelector(".modal-overlay");
      overlay.addEventListener("click", this.toggleModal);

      const closeModal = document.querySelectorAll(".modal-close");
      closeModal.forEach((buttonClose) =>
        buttonClose.addEventListener("click", this.toggleModal)
      );
    },
  },
  /* PUTO
  //El async funciona porque vue es Reactivo, pero no esta preparado para usar la promesa y esperarla.
  //Esto no es aplicable en SSR, debido a que el servidor no espera a la respuesta. Por lo tanto, no se podria hacer.
  // La unica accion del ciclo de vida de Vue que espera, es server prefetch (SOLO EN SSR)
  */
  async mounted() {
    this.itemsList = await getColleges();
    this.setItems();

    this.$nextTick(() => {
      // this.loadModals();
    });
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
}

.wrapper {
  margin-top: 40px;
}
</style>
